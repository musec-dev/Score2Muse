# Score2Muse

Starter web app in modalità ospite: carica un PDF o un'immagine di uno spartito e scarica un file `.mscz`.

## Importante: cosa è già pronto e cosa serve

La pagina web e l'endpoint di conversione sono implementati. Per effettuare conversioni reali, il computer/server che ospita l'app deve avere installati:

1. **Audiveris** (OMR): riconosce la notazione musicale ed esporta MusicXML.
2. **MuseScore** con interfaccia da riga di comando: converte MusicXML in `.mscz`.

Il supporto "all instruments" significa che il flusso accetta spartiti con diversi strumenti; non garantisce una lettura perfetta di ogni impaginazione, manoscritto o partitura complessa. La conversione va controllata in MuseScore.

## Avvio locale

Richiede Python 3.10+ e Audiveris/MuseScore installati e disponibili nel PATH.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

Apri http://127.0.0.1:8000

Se i comandi sul tuo sistema hanno nomi diversi, imposta le variabili:

```bash
AUDIVERIS_CMD=/percorso/al/comando/audiveris
MUSESCORE_CMD=/percorso/al/comando/mscore
```

## Pubblicazione online

Per renderlo accessibile a chiunque, occorre pubblicare l'app su un server che possa eseguire entrambi i programmi. Un hosting statico da solo non basta, perché il riconoscimento OMR e MuseScore devono girare sul server.

Prima della pubblicazione pubblica, aggiungere almeno:
- HTTPS e limiti di utilizzo per IP;
- protezione da abuso e scansioni di file;
- coda di conversione e limiti di tempo/risorse;
- verifica della licenza e dei termini di distribuzione delle versioni di Audiveris e MuseScore usate;
- messaggio privacy chiaro. I file sono trattati in una cartella temporanea e cancellati al termine della richiesta.

## Flusso tecnico

`PDF/immagine → Audiveris (OMR) → MusicXML → MuseScore CLI → .mscz`
