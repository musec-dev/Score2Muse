import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).parent
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "25"))
AUDIVERIS_CMD = os.getenv("AUDIVERIS_CMD", "audiveris")
MUSESCORE_CMD = os.getenv("MUSESCORE_CMD", "mscore")

app = FastAPI(title="Score2Muse")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")

@app.get("/")
def home():
    return FileResponse(APP_DIR / "static" / "index.html")

@app.post("/api/convert")
async def convert(file: UploadFile = File(...)):
    allowed = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(400, "Formato non supportato. Carica PDF, PNG, JPG o TIFF.")
    data = await file.read()
    if not data:
        raise HTTPException(400, "Il file è vuoto.")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File troppo grande. Limite: {MAX_UPLOAD_MB} MB.")

    with tempfile.TemporaryDirectory(prefix="score2muse_") as tmp:
        work = Path(tmp)
        source = work / ("spartito" + suffix)
        source.write_bytes(data)
        omr_dir = work / "omr"
        omr_dir.mkdir()

        # Audiveris riconosce la notazione e esporta MusicXML.
        try:
            subprocess.run(
                [AUDIVERIS_CMD, "-batch", "-export", "-output", str(omr_dir), str(source)],
                check=True, capture_output=True, text=True, timeout=240
            )
        except FileNotFoundError:
            raise HTTPException(503, "Il motore Audiveris non è installato sul server.")
        except subprocess.TimeoutExpired:
            raise HTTPException(504, "La conversione ha superato il tempo massimo.")
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "Errore nel riconoscimento dello spartito")[-1200:]
            raise HTTPException(422, f"Audiveris non è riuscito a leggere lo spartito: {detail}")

        xml_files = list(omr_dir.rglob("*.musicxml")) + list(omr_dir.rglob("*.xml")) + list(omr_dir.rglob("*.mxl"))
        if not xml_files:
            raise HTTPException(422, "Nessun file MusicXML prodotto. Prova con una scansione più nitida.")
        musicxml = xml_files[0]
        output = work / "Score2Muse.mscz"

        # MuseScore converte il MusicXML nel formato nativo .mscz.
        try:
            subprocess.run(
                [MUSESCORE_CMD, "-o", str(output), str(musicxml)],
                check=True, capture_output=True, text=True, timeout=180
            )
        except FileNotFoundError:
            raise HTTPException(503, "MuseScore CLI non è installato sul server.")
        except subprocess.TimeoutExpired:
            raise HTTPException(504, "La creazione del file MuseScore ha superato il tempo massimo.")
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "Errore durante la creazione del file MuseScore")[-1200:]
            raise HTTPException(422, detail)

        if not output.exists():
            raise HTTPException(500, "MuseScore non ha generato il file .mscz.")
        # FileResponse streams the file before TemporaryDirectory cleanup.
        return FileResponse(
            output,
            media_type="application/vnd.musescore",
            filename="spartito_convertito.mscz",
            background=None
        )
